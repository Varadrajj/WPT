function makeAdder(x){
    console.log("x = "+x)
    return function(y){
        console.log("y = "+y)
        return x + y
    }
}

const add5 = makeAdder(5)
const add10 = makeAdder(10)
const add12 = makeAdder(15)

console.log("Sum =" + add5(5))
console.log("Sum =" + add10(5))
console.log("Sum =" + add12(3), add12(4))