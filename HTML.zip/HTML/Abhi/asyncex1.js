let callback = () => {console.log("Hi")}
let intervalId = setInterval(callback, 1000)

// setTimeout(() =>
//     // console.log("Set callback function runs calling clearInterval")
//     clearInterval(intervalId)
// , 7000);

setTimeout(function () { clearInterval(intervalId)},5000);