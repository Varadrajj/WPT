let today = new Date()
console.log(today)

console.log(today.getDate(), "/", today.getMonth()+1, "/", today.getFullYear())

console.log(today.getDate())

let indday = new Date(2024,7,15)
console.log(indday.getDay())  

let newyearday = new Date(2023,12,31)
console.log(newyearday.getDay())



