let today=new Date()
console.log(today)


console.log(today.getDate(),"-",today.getMonth()+1,"-",today.getFullYear())

let indDay=new Date(2024,7,15)
console.log(indDay.getDate())

let yearEnd= new Date("2023-12-31")
console.log(yearEnd.getDate())
console.log(yearEnd.getDay())

let birthdate=new Date(2000,9,8)
let diff=today-birthdate
let dias=Math.floor(diff/(1000*60))
console.log(diff,dias)