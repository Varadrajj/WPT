//Synchronous Callback Function
// function doJob(f1){
//     f1()
// }
// doJob(function(){
//     console.log("Hii")
// })


let arr=[10,20,30,40,50]
// let callback=(element,ind,arr)=>{
//     console.log(ind,element,arr)
// }
// arr.forEach(callback)


//arr.forEach((element,ind,arr)=>{console.log(ind,element,arr)})

// let squares = arr.map((element)=>{return Math.pow(element,2)})
// console.log(squares)

// let divby4 = arr.filter((element)=>{
//     if(element % 4 == 0){
//         return true;
//     }else {
//         return false;
//     }
// })

// console.log(divby4)

// arr.forEach((element,ind,arr)=>{console.log(ind,element,arr)})

// let squares=arr.map((element)=>{return Math.pow(element,2)})
// console.log(squares)

// let div=arr.filter(function(element){
//     if(element%4==0){
//         return true
//     }else{
//         return false
//     }
// })
// console.log(div)

