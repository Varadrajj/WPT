import express from "express"

let a=express()
a.get("/",(req,res)=>{
    console.log("Request Arrived")
    res.send("Hi from MyWebServer")
})
a.listen(7000,()=>{
    console.log("Server is listening on 7000....")
})