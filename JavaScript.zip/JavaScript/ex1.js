// console.log("hello World")
// let x=2;
// console.log("x =",x)
// x="flowers";
// console.log("x =",x,typeof(x))

// let x;
// for(x=1; x<=10; x++){
//     console.log("x ="+x)
// }

// x=`this is a string
//     on new line`
// x=new String("Hellyueuuuu")
// x=true
// x=[10, 20, 30, 40]
// x=[10, 20, 30, 40,true,"russia"]
// console.log("x= ",x,typeof(x))

// const x=44;
// x=33;
// console.log(x)

// var p=100
// {
//     var p=200
// }
// console.log("P = "+p)