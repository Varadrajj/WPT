let obj={
    fname:"Varadraj",
    lname:"Jagdale",
    job:"At CDAC",
    address:{
        area:"ShivajiNagar",
        city:"Pune",
        state:"Maharashtra",
        pin:"411100"
    } ,
    skills:["C/C++","DBMS","Java","DSA"],

    show:function(){
        console.log(this.fname,this.lname)
    }
    

}

// console.log(obj.fname,obj.lname,obj.job)
// console.log(obj.address.area,obj["address"]["city"],obj["address"].state)
// console.log(obj.skills[2])
// obj.show()

// console.log(obj)
// console.log(JSON.stringify(obj))

let rv=JSON.stringify(obj)
console.log(typeof(rv))

let ob=JSON.parse(rv)
console.log(ob)
console.log(JSON.stringify(ob))
console.log(ob.address.city)