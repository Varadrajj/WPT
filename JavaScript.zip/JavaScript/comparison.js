let s1
let s2
// s2='Hello'
// s1=new String("Hello")
// s2=new String("Hello")

s1="Hello"
s2="Hello"

// s1="Hello"
// s2=new String("Hello")



if(s1 === s2)
    console.log("Same")
else
    console.log("Different")
