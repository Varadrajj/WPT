// let x=2
// console.log("x= ",x)
// x="Varadraj"
// console.log("x= ",x,typeof(x))

// let y
// for(y=1;y<10;y++){
//     console.log("y= ",y)
// }

//x=10
// x='flowers'
// x="flowers"
// x=`Welcome to IET
//    Cdac centre `
// x=true
// x=[10,20,30]
// x=[10,20,30,"India",true]
// x=new String("Hello")
//  console.log(typeof(x))

// const y=33

// console.log(y)
var p=100
{
    let q
    var p=200
}
q=800
console.log(q)
console.log(p)

